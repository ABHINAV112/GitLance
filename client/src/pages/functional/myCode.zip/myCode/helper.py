def single_move(cube,move):
    if move=='u':
        cube[0][0],cube[0][1],cube[0][2],cube[0][5],cube[0][8],cube[0][7],cube[0][6],cube[0][3]=cube[0][6],cube[0][3],cube[0][0],cube[0][1],cube[0][2],cube[0][5],cube[0][8],cube[0][7]
        cube[1][0],cube[1][1],cube[1][2],cube[2][0],cube[2][1],cube[2][2],cube[3][0],cube[3][1],cube[3][2],cube[4][0],cube[4][1],cube[4][2]=cube[2][0],cube[2][1],cube[2][2],cube[3][0],cube[3][1],cube[3][2],cube[4][0],cube[4][1],cube[4][2],cube[1][0],cube[1][1],cube[1][2]
    elif move=="u'":
        cube[0][0],cube[0][1],cube[0][2],cube[0][5],cube[0][8],cube[0][7],cube[0][6],cube[0][3]=cube[0][2],cube[0][5],cube[0][8],cube[0][7],cube[0][6],cube[0][3],cube[0][0],cube[0][1]
        cube[1][0],cube[1][1],cube[1][2],cube[2][0],cube[2][1],cube[2][2],cube[3][0],cube[3][1],cube[3][2],cube[4][0],cube[4][1],cube[4][2]=cube[4][0],cube[4][1],cube[4][2],cube[1][0],cube[1][1],cube[1][2],cube[2][0],cube[2][1],cube[2][2],cube[3][0],cube[3][1],cube[3][2]
    elif move=='f':
        cube[1][0],cube[1][1],cube[1][2],cube[1][5],cube[1][8],cube[1][7],cube[1][6],cube[1][3]=cube[1][6],cube[1][3],cube[1][0],cube[1][1],cube[1][2],cube[1][5],cube[1][8],cube[1][7]
        cube[0][6],cube[0][7],cube[0][8],cube[2][0],cube[2][3],cube[2][6],cube[5][2],cube[5][1],cube[5][0],cube[4][8],cube[4][5],cube[4][2]=cube[4][8],cube[4][5],cube[4][2],cube[0][6],cube[0][7],cube[0][8],cube[2][0],cube[2][3],cube[2][6],cube[5][2],cube[5][1],cube[5][0]
    elif move=="f'":
        cube[1][0],cube[1][1],cube[1][2],cube[1][5],cube[1][8],cube[1][7],cube[1][6],cube[1][3]=cube[1][2],cube[1][5],cube[1][8],cube[1][7],cube[1][6],cube[1][3],cube[1][0],cube[1][1]
        cube[0][6],cube[0][7],cube[0][8],cube[2][0],cube[2][3],cube[2][6],cube[5][2],cube[5][1],cube[5][0],cube[4][8],cube[4][5],cube[4][2]=cube[2][0],cube[2][3],cube[2][6],cube[5][2],cube[5][1],cube[5][0],cube[4][8],cube[4][5],cube[4][2],cube[0][6],cube[0][7],cube[0][8]
    elif move=='r':
        cube[2][0],cube[2][1],cube[2][2],cube[2][5],cube[2][8],cube[2][7],cube[2][6],cube[2][3]=cube[2][6],cube[2][3],cube[2][0],cube[2][1],cube[2][2],cube[2][5],cube[2][8],cube[2][7]
        cube[1][8],cube[1][5],cube[1][2],cube[0][8],cube[0][5],cube[0][2],cube[3][0],cube[3][3],cube[3][6],cube[5][8],cube[5][5],cube[5][2]=cube[5][8],cube[5][5],cube[5][2],cube[1][8],cube[1][5],cube[1][2],cube[0][8],cube[0][5],cube[0][2],cube[3][0],cube[3][3],cube[3][6]
    elif move=="r'":
        cube[2][0],cube[2][1],cube[2][2],cube[2][5],cube[2][8],cube[2][7],cube[2][6],cube[2][3]=cube[2][2],cube[2][5],cube[2][8],cube[2][7],cube[2][6],cube[2][3],cube[2][0],cube[2][1]
        cube[1][8],cube[1][5],cube[1][2],cube[0][8],cube[0][5],cube[0][2],cube[3][0],cube[3][3],cube[3][6],cube[5][8],cube[5][5],cube[5][2]=cube[0][8],cube[0][5],cube[0][2],cube[3][0],cube[3][3],cube[3][6],cube[5][8],cube[5][5],cube[5][2],cube[1][8],cube[1][5],cube[1][2]
    elif move=='l':
        cube[4][0],cube[4][1],cube[4][2],cube[4][5],cube[4][8],cube[4][7],cube[4][6],cube[4][3]=cube[4][6],cube[4][3],cube[4][0],cube[4][1],cube[4][2],cube[4][5],cube[4][8],cube[4][7]
        cube[1][6],cube[1][3],cube[1][0],cube[0][6],cube[0][3],cube[0][0],cube[3][2],cube[3][5],cube[3][8],cube[5][6],cube[5][3],cube[5][0]=cube[0][6],cube[0][3],cube[0][0],cube[3][2],cube[3][5],cube[3][8],cube[5][6],cube[5][3],cube[5][0],cube[1][6],cube[1][3],cube[1][0]
    elif move=="l'":
        cube[4][0],cube[4][1],cube[4][2],cube[4][5],cube[4][8],cube[4][7],cube[4][6],cube[4][3]=cube[4][2],cube[4][5],cube[4][8],cube[4][7],cube[4][6],cube[4][3],cube[4][0],cube[4][1]
        cube[1][6],cube[1][3],cube[1][0],cube[0][6],cube[0][3],cube[0][0],cube[3][2],cube[3][5],cube[3][8],cube[5][6],cube[5][3],cube[5][0]=cube[5][6],cube[5][3],cube[5][0],cube[1][6],cube[1][3],cube[1][0],cube[0][6],cube[0][3],cube[0][0],cube[3][2],cube[3][5],cube[3][8]
    elif move=='b':
        cube[3][0],cube[3][1],cube[3][2],cube[3][5],cube[3][8],cube[3][7],cube[3][6],cube[3][3]=cube[3][6],cube[3][3],cube[3][0],cube[3][1],cube[3][2],cube[3][5],cube[3][8],cube[3][7]
        cube[0][2],cube[0][1],cube[0][0],cube[4][0],cube[4][3],cube[4][6],cube[5][6],cube[5][7],cube[5][8],cube[2][8],cube[2][5],cube[2][2]=cube[2][8],cube[2][5],cube[2][2],cube[0][2],cube[0][1],cube[0][0],cube[4][0],cube[4][3],cube[4][6],cube[5][6],cube[5][7],cube[5][8]
    elif move=="b'":
        cube[3][0],cube[3][1],cube[3][2],cube[3][5],cube[3][8],cube[3][7],cube[3][6],cube[3][3]=cube[3][2],cube[3][5],cube[3][8],cube[3][7],cube[3][6],cube[3][3],cube[3][0],cube[3][1]
        cube[0][2],cube[0][1],cube[0][0],cube[4][0],cube[4][3],cube[4][6],cube[5][6],cube[5][7],cube[5][8],cube[2][8],cube[2][5],cube[2][2]=cube[4][0],cube[4][3],cube[4][6],cube[5][6],cube[5][7],cube[5][8],cube[2][8],cube[2][5],cube[2][2],cube[0][2],cube[0][1],cube[0][0]
    elif move=='d':
        cube[5][0],cube[5][1],cube[5][2],cube[5][5],cube[5][8],cube[5][7],cube[5][6],cube[5][3]=cube[5][6],cube[5][3],cube[5][0],cube[5][1],cube[5][2],cube[5][5],cube[5][8],cube[5][7]
        cube[1][6],cube[1][7],cube[1][8],cube[2][6],cube[2][7],cube[2][8],cube[3][6],cube[3][7],cube[3][8],cube[4][6],cube[4][7],cube[4][8]=cube[4][6],cube[4][7],cube[4][8],cube[1][6],cube[1][7],cube[1][8],cube[2][6],cube[2][7],cube[2][8],cube[3][6],cube[3][7],cube[3][8]
    elif move=="d'":
        cube[5][0],cube[5][1],cube[5][2],cube[5][5],cube[5][8],cube[5][7],cube[5][6],cube[5][3]=cube[5][2],cube[5][5],cube[5][8],cube[5][7],cube[5][6],cube[5][3],cube[5][0],cube[5][1]
        cube[1][6],cube[1][7],cube[1][8],cube[2][6],cube[2][7],cube[2][8],cube[3][6],cube[3][7],cube[3][8],cube[4][6],cube[4][7],cube[4][8]=cube[2][6],cube[2][7],cube[2][8],cube[3][6],cube[3][7],cube[3][8],cube[4][6],cube[4][7],cube[4][8],cube[1][6],cube[1][7],cube[1][8]

def moves(cube,moves):
    for move in moves:
        single_move(cube,move)

def orientation(mov,front,top):
    front=front.lower()
    top=top.lower()
    algo=[]
    key={'u':'u',"u'":"u'",'f':'f',"f'":"f'",'r':'r',"r'":"r'",'l':'l',"l'":"l'",'b':'b',"b'":"b'",'d':'d',"d'":"d'"}
    if front=='w':
        if top=='b':
            key={'u':'u',"u'":"u'",'f':'f',"f'":"f'",'r':'r',"r'":"r'",'l':'l',"l'":"l'",'b':'b',"b'":"b'",'d':'d',"d'":"d'"}
        elif top=='r':
            key={'u':'r',"u'":"r'",'f':'f',"f'":"f'",'r':'d',"r'":"d'",'l':'u',"l'":"u'",'b':'b',"b'":"b'",'d':'l',"d'":"l'"}
        elif top=='g':
            key={'u':'d',"u'":"d'",'f':'f',"f'":"f'",'r':'l',"r'":"l'",'l':'r',"l'":"r'",'b':'b',"b'":"b'",'d':'u',"d'":"u'"}
        elif top=='o':
            key={'u':'l',"u'":"l'",'f':'f',"f'":"f'",'r':'u',"r'":"u'",'l':'d',"l'":"d'",'b':'b',"b'":"b'",'d':'r',"d'":"r'"}
    elif front=='r':
        if top=='b':
            key={'u':'u',"u'":"u'",'f':'r',"f'":"r'",'r':'b',"r'":"b'",'l':'f',"l'":"f'",'b':'l',"b'":"l'",'d':'d',"d'":"d'"}
        elif top=='y':
            key={'u':'b',"u'":"b'",'f':'r',"f'":"r'",'r':'d',"r'":"d'",'l':'u',"l'":"u'",'b':'l',"b'":"l'",'d':'f',"d'":"f'"}
        elif top=='g':
            key={'u':'d',"u'":"d'",'f':'r',"f'":"r'",'r':'f',"r'":"f'",'l':'b',"l'":"b'",'b':'l',"b'":"l'",'d':'u',"d'":"u'"}
        elif top=='w':
            key={'u':'f',"u'":"f'",'f':'r',"f'":"r'",'r':'u',"r'":"u'",'l':'d',"l'":"d'",'b':'l',"b'":"l'",'d':'b',"d'":"b'"}
    elif front=='y':
        if top=='b':
            key={'u':'u',"u'":"u'",'f':'b',"f'":"b'",'r':'l',"r'":"l'",'l':'r',"l'":"r'",'b':'f',"b'":"f'",'d':'d',"d'":"d'"}
        elif top=='o':
            key={'u':'l',"u'":"l'",'f':'b',"f'":"b'",'r':'d',"r'":"d'",'l':'u',"l'":"u'",'b':'f',"b'":"f'",'d':'r',"d'":"r'"}
        elif top=='g':
            key={'u':'d',"u'":"d'",'f':'b',"f'":"b'",'r':'r',"r'":"r'",'l':'l',"l'":"l'",'b':'f',"b'":"f'",'d':'u',"d'":"u'"}
        elif top=='r':
            key={'u':'r',"u'":"r'",'f':'b',"f'":"b'",'r':'u',"r'":"u'",'l':'d',"l'":"d'",'b':'f',"b'":"f'",'d':'l',"d'":"l'"}
    elif front=='o':
        if top=='b':
            key={'u':'u',"u'":"u'",'f':'l',"f'":"l'",'r':'f',"r'":"f'",'l':'b',"l'":"b'",'b':'r',"b'":"r'",'d':'d',"d'":"d'"}
        elif top=='w':
            key={'u':'f',"u'":"f'",'f':'l',"f'":"l'",'r':'d',"r'":"d'",'l':'u',"l'":"u'",'b':'r',"b'":"r'",'d':'b',"d'":"b'"}
        elif top=='g':
            key={'u':'d',"u'":"d'",'f':'l',"f'":"l'",'r':'b',"r'":"b'",'l':'f',"l'":"f'",'b':'r',"b'":"r'",'d':'u',"d'":"u'"}
        elif top=='y':
            key={'u':'b',"u'":"b'",'f':'l',"f'":"l'",'r':'u',"r'":"u'",'l':'d',"l'":"d'",'b':'r',"b'":"r'",'d':'f',"d'":"f'"}
    elif front=='b':
        if top=='r':
            key={'u':'r',"u'":"r'",'f':'u',"f'":"u'",'r':'f',"r'":"f'",'l':'b',"l'":"b'",'b':'d',"b'":"d'",'d':'l',"d'":"l'"}
        elif top=='w':
            key={'u':'f',"u'":"f'",'f':'u',"f'":"u'",'r':'l',"r'":"l'",'l':'r',"l'":"r'",'b':'d',"b'":"d'",'d':'b',"d'":"b'"}
        elif top=='o':
            key={'u':'l',"u'":"l'",'f':'u',"f'":"u'",'r':'b',"r'":"b'",'l':'f',"l'":"f'",'b':'d',"b'":"d'",'d':'r',"d'":"r'"}
        elif top=='y':
            key={'u':'b',"u'":"b'",'f':'u',"f'":"u'",'r':'r',"r'":"r'",'l':'l',"l'":"l'",'b':'d',"b'":"d'",'d':'f',"d'":"f'"}
    elif front=='g':
        if top=='w':
            key={'u':'f',"u'":"f'",'f':'d',"f'":"d'",'r':'r',"r'":"r'",'l':'l',"l'":"l'",'b':'u',"b'":"u'",'d':'b',"d'":"b'"}
        elif top=='r':
            key={'u':'r',"u'":"r'",'f':'d',"f'":"d'",'r':'b',"r'":"b'",'l':'f',"l'":"f'",'b':'u',"b'":"u'",'d':'l',"d'":"l'"}
        elif top=='y':
            key={'u':'b',"u'":"b'",'f':'d',"f'":"d'",'r':'l',"r'":"l'",'l':'r',"l'":"r'",'b':'u',"b'":"u'",'d':'f',"d'":"f'"}
        elif top=='o':
            key={'u':'l',"u'":"l'",'f':'d',"f'":"d'",'r':'f',"r'":"f'",'l':'b',"l'":"b'",'b':'u',"b'":"u'",'d':'r',"d'":"r'"}
    for m in mov:
        algo.append(key[m])
    return algo

def find_edge(c1,c2,cube):
    edges=[[5,1,1,7],[5,5,2,7],[5,7,3,7],[5,3,4,7],[1,5,2,3],[2,5,3,3],[3,5,4,3],[4,5,1,3],[0,1,3,1],[0,3,4,1],[0,5,2,1],[0,7,1,1]]
    for edge in edges:
        e=[cube[edge[0]][edge[1]],cube[edge[2]][edge[3]]]
        if (c1 in e) and (c2 in e):
            break
    if c1!=e[0]:
        edge[0],edge[1],edge[2],edge[3]=edge[2],edge[3],edge[0],edge[1]
    return edge

def find_corner(c1,c2,c3,cube):
    corners=[[5,0,1,6,4,8],[5,2,1,8,2,6],[5,6,3,8,4,6],[5,8,2,8,3,6],[0,0,3,2,4,0],[0,2,2,2,3,0],[0,6,1,0,4,2],[0,8,1,2,2,0]]
    for corner in corners:
        c=[cube[corner[0]][corner[1]],cube[corner[2]][corner[3]],cube[corner[4]][corner[5]]]
        if (c1 in c) and (c2 in c) and (c3 in c):
            break
    for index in range(3):
        if c1==c[index]:
            c1_l=index
        elif c2==c[index]:
            c2_l=index
        else:
            c3_l=index

    return corner[2*c1_l:2*c1_l+2]+corner[2*c2_l:2*c2_l+2]+corner[2*c3_l:2*c3_l+2]

def shuffle(cube):
    move=['f',"f'",'r',"r'",'l',"l'",'u',"u'",'d',"d'",'b',"b'"]
    shuffle_moves=[]
    for i in range(30):
        shuffle_moves.append(random.choice(move))
    moves(cube,shuffle_moves)

def efficient(sol):
    i=0
    while i<len(sol)-1:
        check=0
        if i<len(sol)-2:
            if sol[i]==sol[i+1] and sol[i+1]==sol[i+2]:
                del sol[i+1]
                del sol[i+1]
                if len(sol[i])==1:
                    sol[i]=sol[i]+"'"
                else:
                    sol[i]=sol[i][0]
                check=1
        if i<len(sol)-1:
            if sol[i][0]==sol[i+1][0] and ((len(sol[i])==1 and len(sol[i+1])==2) or (len(sol[i])==2 and len(sol[i+1])==1)):
                del sol[i]
                del sol[i]
                check=1
        if check!=1:
            i+=1
def shuffle(cube):
    import random
    move=['f',"f'",'r',"r'",'l',"l'",'u',"u'",'d',"d'",'b',"b'"]
    shuffle_moves=[]
    for i in range(30):
        shuffle_moves.append(random.choice(move))
    moves(cube,shuffle_moves)