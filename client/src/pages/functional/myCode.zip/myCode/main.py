from solution import *
from helper import *

n = int(input())

for i in range(n):
    cube = []
    for j in range(6):
        cube.append(input().split())
    # print(cube)
    f = first_layer(cube)
    s = second_layer(cube)
    t = third_layer(cube)
    efficient(f)
    efficient(s)
    efficient(t)
    print(f+s+t)